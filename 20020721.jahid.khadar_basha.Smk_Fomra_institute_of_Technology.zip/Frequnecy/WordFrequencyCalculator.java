import java.util.HashMap;
import java.util.Map;

public class WordFrequencyCalculator {
    public static void main(String[] args) {
        String text = "this is Shaik Jahid from SMK FOMRA INSTITUTE OF TECHNOLOGY final year CSE Department Near kelembakkam this is assessment for space zee ";

        Map<String, Integer> frequencyMap = calculateWordFrequency(text);

        for (Map.Entry<String, Integer> entry : frequencyMap.entrySet()) {
            String word = entry.getKey();
            int frequency = entry.getValue();
            System.out.println("Word: " + word + ", Frequency: " + frequency);
        }
    }

    public static Map<String, Integer> calculateWordFrequency(String text) {
        Map<String, Integer> frequencyMap = new HashMap<>();

        String[] words = text.split(" ");

        for (String word : words) {
            if (frequencyMap.containsKey(word)) {
                frequencyMap.put(word, frequencyMap.get(word) + 1);
            } else {
                frequencyMap.put(word, 1);
            }
        }

        return frequencyMap;
}
}