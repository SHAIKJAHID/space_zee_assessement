public class MemoryMeasurement
 {
    public static void main(String[] args)
 {
        Runtime runtime = Runtime.getRuntime();

        runtime.gc();

        long initialMemory = runtime.totalMemory() - runtime.freeMemory();
        System.out.println("Initial Memory Usage: " + initialMemory + " bytes");
        int[] array = new int[10_000_000];

        long memoryAfterAllocation = runtime.totalMemory() - runtime.freeMemory();
        System.out.println("Memory Usage after Allocation: " + memoryAfterAllocation + " bytes");
        array = null;
        runtime.gc();

        long finalMemory = runtime.totalMemory() - runtime.freeMemory();
        System.out.println("Final Memory Usage: " + finalMemory + " bytes");
    }
}

