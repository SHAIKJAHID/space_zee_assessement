import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class TranslationProgram {
    private static final String INPUT_FILE_PATH = "C:/Users/DELL/OneDrive/Desktop/input.txt";
    private static final String OUTPUT_FILE_PATH ="C:/Users/DELL/OneDrive/Desktop/output.txt";

    private static final Map<String, String> translationMap;

    static {
        translationMap = new HashMap<>();
        translationMap.put("hello", "bonjour");
        translationMap.put("world", "monde");
        // Add more word translations as needed
    }

    public static void main(String[] args) {
        try {
            BufferedReader reader = new BufferedReader(new FileReader(INPUT_FILE_PATH));
            BufferedWriter writer = new BufferedWriter(new FileWriter(OUTPUT_FILE_PATH));

            String line;
            while ((line = reader.readLine()) != null) {
                String[] words = line.split("\\s+");
                StringBuilder translatedLine = new StringBuilder();

                for (String word : words) {
                    String translatedWord = translationMap.getOrDefault(word.toLowerCase(), word);
                    translatedLine.append(translatedWord).append(" ");
                }

                writer.write(translatedLine.toString().trim());
                writer.newLine();
            }

            reader.close();
            writer.close();

            System.out.println("Translation completed successfully.");
        } catch (IOException e) {
            System.out.println("An error occurred: " + e.getMessage());
        }
    }
}
